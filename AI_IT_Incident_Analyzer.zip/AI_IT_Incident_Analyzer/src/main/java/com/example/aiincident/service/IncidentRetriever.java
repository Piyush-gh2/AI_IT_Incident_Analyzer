package com.example.aiincident.service;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IncidentRetriever {

    private final EmbeddingService embeddingService;
    private final InMemoryVectorStore vectorStore;
    private final VectorSimilarityService vectorSimilarityService;

    public IncidentRetriever(
            EmbeddingService embeddingService,
            InMemoryVectorStore vectorStore,
            VectorSimilarityService vectorSimilarityService) {

        this.embeddingService = embeddingService;
        this.vectorStore = vectorStore;
        this.vectorSimilarityService = vectorSimilarityService;
    }

    public RetrievalResult retrieveRelevantIncident(
            String incidentTitle,
            String incidentDescription,
            String knowledgeBase) {

        String query =
                incidentTitle + " " + incidentDescription;

        System.out.println();
        System.out.println(
                "========== SEMANTIC RETRIEVAL =========="
        );

        System.out.println(
                "New Incident: " + query
        );

        // Generate embedding for new incident
        List<Double> queryEmbedding =
                embeddingService.generateEmbedding(query);

        KnowledgeDocument bestDocument = null;
        double highestSimilarity = -1.0;

        // Compare with all historical incidents
        for (KnowledgeDocument document :
                vectorStore.getDocuments()) {

            double similarity =
                    vectorSimilarityService.cosineSimilarity(
                            queryEmbedding,
                            document.getEmbedding()
                    );

            System.out.printf(
                    "Similarity Score: %.4f%n",
                    similarity
            );

            if (similarity > highestSimilarity) {

                highestSimilarity = similarity;
                bestDocument = document;
            }
        }

        System.out.println(
                "-----------------------------------------"
        );

        if (bestDocument != null) {

            System.out.printf(
                    "BEST MATCH SCORE: %.4f%n",
                    highestSimilarity
            );

            System.out.println(
                    "BEST MATCH INCIDENT:"
            );

            System.out.println(
                    bestDocument.getContent()
            );
        }

        System.out.println(
                "========================================="
        );

        System.out.println();

        if (bestDocument != null) {

            return new RetrievalResult(
                    bestDocument.getContent(),
                    highestSimilarity
            );
        }

        return new RetrievalResult(
                knowledgeBase,
                0.0
        );
    }
}