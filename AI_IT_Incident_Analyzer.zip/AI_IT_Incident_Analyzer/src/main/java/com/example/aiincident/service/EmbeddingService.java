package com.example.aiincident.service;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.List;
import java.util.Map;

@Service
public class EmbeddingService {

    private final RestClient restClient;

    public EmbeddingService() {

        this.restClient = RestClient.builder()
                .baseUrl("http://host.docker.internal:11434")
                .build();
    }

    public List<Double> generateEmbedding(String text) {

        Map<String, Object> requestBody = Map.of(
                "model", "nomic-embed-text",
                "input", text
        );

        Map<String, Object> response = restClient.post()
                .uri("/api/embed")
                .contentType(MediaType.APPLICATION_JSON)
                .body(requestBody)
                .retrieve()
                .body(Map.class);

        List<List<Double>> embeddings =
                (List<List<Double>>) response.get("embeddings");

        return embeddings.get(0);
    }
}