package com.example.aiincident.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class IncidentRequest {

    @NotBlank(message = "Incident title is required")
    @Size(
            max = 200,
            message = "Incident title must not exceed 200 characters"
    )
    private String title;

    @NotBlank(message = "Incident description is required")
    @Size(
            max = 5000,
            message = "Incident description must not exceed 5000 characters"
    )
    private String description;

    public IncidentRequest() {

    }

    public IncidentRequest(String title, String description) {

        this.title = title;
        this.description = description;
    }

    public String getTitle() {

        return title;
    }

    public void setTitle(String title) {

        this.title = title;
    }

    public String getDescription() {

        return description;
    }

    public void setDescription(String description) {

        this.description = description;
    }
}