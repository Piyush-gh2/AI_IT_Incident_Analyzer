package com.example.aiincident.service;

import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class InMemoryVectorStore {

    private final KnowledgeBaseService knowledgeBaseService;
    private final EmbeddingService embeddingService;

    private final List<KnowledgeDocument> documents =
            new ArrayList<>();

    public InMemoryVectorStore(
            KnowledgeBaseService knowledgeBaseService,
            EmbeddingService embeddingService) {

        this.knowledgeBaseService = knowledgeBaseService;
        this.embeddingService = embeddingService;
    }

    @PostConstruct
    public void initialize() {

        System.out.println(
                "========== BUILDING VECTOR STORE =========="
        );

        String knowledgeBase =
                knowledgeBaseService.loadKnowledgeBase();

        String[] incidents =
                knowledgeBase.split(
                        "--------------------------------------------------"
                );

        for (String incident : incidents) {

            if (incident.isBlank()) {
                continue;
            }

            String incidentText = incident.trim();

            System.out.println(
                    "Generating embedding for incident..."
            );

            List<Double> embedding =
                    embeddingService.generateEmbedding(
                            incidentText
                    );

            KnowledgeDocument document =
                    new KnowledgeDocument(
                            incidentText,
                            embedding
                    );

            documents.add(document);
        }

        System.out.println(
                "Total documents in vector store: "
                        + documents.size()
        );

        System.out.println(
                "============================================"
        );
    }

    public List<KnowledgeDocument> getDocuments() {
        return documents;
    }
}