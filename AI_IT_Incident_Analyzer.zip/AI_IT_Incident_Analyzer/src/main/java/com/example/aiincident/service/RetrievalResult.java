package com.example.aiincident.service;

public class RetrievalResult {

    private final String content;
    private final double similarityScore;

    public RetrievalResult(
            String content,
            double similarityScore) {

        this.content = content;
        this.similarityScore = similarityScore;
    }

    public String getContent() {
        return content;
    }

    public double getSimilarityScore() {
        return similarityScore;
    }
}