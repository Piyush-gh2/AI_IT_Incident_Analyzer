package com.example.aiincident;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AiItIncidentAnalyzerApplication {

    public static void main(String[] args) {

        SpringApplication.run(
                AiItIncidentAnalyzerApplication.class,
                args
        );
    }
}