package com.example.aiincident.controller;

import com.example.aiincident.dto.AIAnalysisResponse;
import com.example.aiincident.dto.IncidentRequest;
import com.example.aiincident.service.EmbeddingService;
import com.example.aiincident.service.IncidentService;

import jakarta.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/incidents")
public class IncidentController {

    private final IncidentService incidentService;
    private final EmbeddingService embeddingService;

    public IncidentController(
            IncidentService incidentService,
            EmbeddingService embeddingService) {

        this.incidentService = incidentService;
        this.embeddingService = embeddingService;
    }

    // ==========================================
    // ANALYZE IT INCIDENT
    // ==========================================

    @PostMapping("/analyze")
    public ResponseEntity<AIAnalysisResponse> analyzeIncident(
            @Valid @RequestBody IncidentRequest incidentRequest) {

        AIAnalysisResponse response =
                incidentService.analyzeIncident(incidentRequest);

        return ResponseEntity.ok(response);
    }

    // ==========================================
    // TEST EMBEDDING
    // ==========================================

    @GetMapping("/embedding")
    public ResponseEntity<Object> testEmbedding(
            @RequestParam String text) {

        return ResponseEntity.ok(
                embeddingService.generateEmbedding(text)
        );
    }
}