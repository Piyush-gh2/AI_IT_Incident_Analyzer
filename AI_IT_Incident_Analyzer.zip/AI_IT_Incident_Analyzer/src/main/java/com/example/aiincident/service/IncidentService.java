package com.example.aiincident.service;

import com.example.aiincident.dto.AIAnalysisResponse;
import com.example.aiincident.dto.IncidentRequest;

import org.springframework.stereotype.Service;

@Service
public class IncidentService {

    private final LLMService llmService;
    private final KnowledgeBaseService knowledgeBaseService;
    private final IncidentRetriever incidentRetriever;

    public IncidentService(
            LLMService llmService,
            KnowledgeBaseService knowledgeBaseService,
            IncidentRetriever incidentRetriever) {

        this.llmService = llmService;
        this.knowledgeBaseService = knowledgeBaseService;
        this.incidentRetriever = incidentRetriever;
    }

    public AIAnalysisResponse analyzeIncident(
            IncidentRequest incidentRequest) {

        String knowledgeBase =
                knowledgeBaseService.loadKnowledgeBase();

        RetrievalResult retrievalResult =
                incidentRetriever.retrieveRelevantIncident(
                        incidentRequest.getTitle(),
                        incidentRequest.getDescription(),
                        knowledgeBase
                );

        AIAnalysisResponse response =
                llmService.analyzeIncident(
                        incidentRequest,
                        retrievalResult.getContent()
                );

        // Add RAG explainability information
        response.setMatchedIncident(
                extractIncidentTitle(
                        retrievalResult.getContent()
                )
        );

        response.setSimilarityScore(
                retrievalResult.getSimilarityScore()
        );

        return response;
    }

    private String extractIncidentTitle(String content) {

        for (String line : content.split("\\R")) {

            if (line.startsWith("Title:")) {

                return line.substring(
                        "Title:".length()
                ).trim();
            }
        }

        return "Unknown";
    }
}