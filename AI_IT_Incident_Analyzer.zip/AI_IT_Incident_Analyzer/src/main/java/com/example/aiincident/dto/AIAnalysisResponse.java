package com.example.aiincident.dto;

public class AIAnalysisResponse {

    private String category;
    private String priority;
    private String summary;
    private String rootCause;
    private String recommendation;

    // RAG explainability fields
    private String matchedIncident;
    private double similarityScore;

    public AIAnalysisResponse() {
    }

    public AIAnalysisResponse(
            String category,
            String priority,
            String summary,
            String rootCause,
            String recommendation,
            String matchedIncident,
            double similarityScore) {

        this.category = category;
        this.priority = priority;
        this.summary = summary;
        this.rootCause = rootCause;
        this.recommendation = recommendation;
        this.matchedIncident = matchedIncident;
        this.similarityScore = similarityScore;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getRootCause() {
        return rootCause;
    }

    public void setRootCause(String rootCause) {
        this.rootCause = rootCause;
    }

    public String getRecommendation() {
        return recommendation;
    }

    public void setRecommendation(String recommendation) {
        this.recommendation = recommendation;
    }

    public String getMatchedIncident() {
        return matchedIncident;
    }

    public void setMatchedIncident(String matchedIncident) {
        this.matchedIncident = matchedIncident;
    }

    public double getSimilarityScore() {
        return similarityScore;
    }

    public void setSimilarityScore(double similarityScore) {
        this.similarityScore = similarityScore;
    }
}