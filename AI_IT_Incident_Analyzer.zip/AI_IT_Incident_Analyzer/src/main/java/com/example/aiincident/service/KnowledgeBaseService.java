package com.example.aiincident.service;

import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

@Service
public class KnowledgeBaseService {

    public String loadKnowledgeBase() {

        try {

            ClassPathResource resource =
                    new ClassPathResource("knowledge/incident_knowledge.txt");

            return new String(
                    resource.getInputStream().readAllBytes(),
                    StandardCharsets.UTF_8
            );

        } catch (IOException e) {

            throw new RuntimeException(
                    "Unable to load incident knowledge base",
                    e
            );
        }
    }
}