package com.example.aiincident.service;

import java.util.List;

public class KnowledgeDocument {

    private String content;
    private List<Double> embedding;

    public KnowledgeDocument(
            String content,
            List<Double> embedding) {

        this.content = content;
        this.embedding = embedding;
    }

    public String getContent() {
        return content;
    }

    public List<Double> getEmbedding() {
        return embedding;
    }
}