package com.example.aiincident.service;

import com.example.aiincident.dto.AIAnalysisResponse;
import com.example.aiincident.dto.IncidentRequest;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.Map;

@Service
public class LLMService {

    private final RestClient restClient;
    private final ObjectMapper objectMapper;

    public LLMService(ObjectMapper objectMapper) {

        this.restClient = RestClient.builder()
                .baseUrl("http://host.docker.internal:11434")
                .build();

        this.objectMapper = objectMapper;
    }

    public AIAnalysisResponse analyzeIncident(
            IncidentRequest incidentRequest,
            String knowledgeBase) {

        String prompt = """
                You are an IT Incident Management AI.

                You must analyze the new IT incident using the
                historical incident knowledge provided below.

                ==============================
                HISTORICAL INCIDENT KNOWLEDGE
                ==============================

                %s

                ==============================
                NEW INCIDENT
                ==============================

                Incident Title:
                %s

                Incident Description:
                %s

                ==============================
                INSTRUCTIONS
                ==============================

                Analyze the new incident.

                Use the historical incident knowledge as context
                when determining the category, priority, root cause,
                and recommendation.

                Do not blindly copy a historical incident.
                Use the information that is most relevant to the
                new incident.

                Priority must be exactly one of:
                P1, P2, P3, P4.

                Return ONLY valid JSON.

                Do not use markdown.
                Do not use ```json.
                Do not add explanations.

                Return exactly these fields:

                {
                  "category": "actual incident category",
                  "priority": "P1",
                  "summary": "actual incident summary",
                  "rootCause": "actual possible root cause",
                  "recommendation": "actual recommended solution"
                }
                """.formatted(
                knowledgeBase,
                incidentRequest.getTitle(),
                incidentRequest.getDescription()
        );

        Map<String, Object> requestBody = Map.of(
                "model", "llama3.2",
                "prompt", prompt,
                "stream", false,
                "format", "json"
        );

        Map<String, Object> response = restClient.post()
                .uri("/api/generate")
                .contentType(MediaType.APPLICATION_JSON)
                .body(requestBody)
                .retrieve()
                .body(Map.class);

        String aiText = response.get("response").toString();

        System.out.println(
                "========== OLLAMA RAG RESPONSE =========="
        );

        System.out.println(aiText);

        System.out.println(
                "=========================================="
        );

        try {

            return objectMapper.readValue(
                    aiText,
                    AIAnalysisResponse.class
            );

        } catch (Exception e) {

            throw new RuntimeException(
                    "Failed to parse LLM response as JSON",
                    e
            );
        }
    }
}