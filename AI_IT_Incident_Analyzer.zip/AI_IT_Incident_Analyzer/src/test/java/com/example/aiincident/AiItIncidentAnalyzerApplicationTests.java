package com.example.aiincident;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AiItIncidentAnalyzerApplicationTests {

	@Test
	void contextLoads() {
	}

}
